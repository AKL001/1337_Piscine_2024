#!/bin/bash
git log -n 5 --format="%H"
